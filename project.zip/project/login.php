<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "accounts";

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Sanitize user input
$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
$password = filter_var($_POST['pswd'], FILTER_SANITIZE_SPECIAL_CHARS); // Change to FILTER_SANITIZE_SPECIAL_CHARS

// Check if user exists with the provided email
$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "Input password: $password<br>";
    echo "Stored password: {$row['password']}<br>";
    // Verify password using secure hashing algorithm
    if (password_verify($password, $row['password'])) {
        // Start session and store user data
        session_start();
        $_SESSION['user_id'] = $row['id'];

        // Redirect to index.html
        header("Location: index.html");
        exit();
    } else {
        // Invalid password
        echo "Incorrect email or password.";
    }
} else {
    // User not found
    echo "User not found.";
}

// Close database connection
$conn->close();
?>
