<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "accounts";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the user input from the sign up form
$user = $_POST["username"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$pass = $_POST["password"];

// Hash the password using bcrypt
$hash = password_hash($pass, PASSWORD_BCRYPT);

// Check if the username or email already exists in the database
$sql = "SELECT * FROM users WHERE username = '$user' OR email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Username or email already taken
  echo "Sorry, that username or email is already in use.";
} else {
  // Insert the new user into the database
  $sql = "INSERT INTO users (username, email, phone, password) VALUES ('$user', '$email', '$phone', '$hash')";
  if ($conn->query($sql) === TRUE) {
    // Sign up successful
    echo "Welcome, $user! You have successfully signed up.";
  } else {
    // Sign up failed
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

// Close the database connection
$conn->close();
?>
